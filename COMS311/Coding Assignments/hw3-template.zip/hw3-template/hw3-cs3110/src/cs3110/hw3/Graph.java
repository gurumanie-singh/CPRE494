package cs3110.hw3;



public class Graph<T> {

    /* This class must have a default constructor. */
    public Graph() {}

    /**
     * Adds a vertex to the graph.
     *
     * @param u
     * @return False if vertex u was already in the graph, True otherwise.
     */
    public boolean addVertex(T u) {
        /* TODO */
    }

    /**
     * Adds edge (u,v) to the graph.
     *
     * @param u
     * @param v
     * @return Returns false if the edge was already present, true otherwise.
     */
    public boolean addEdge(T u, T v) {
        /* TODO */
    }

    /**
     * @return |V|
     */
    public int getVertexCount() {
        /* TODO */
    }

    /**
     * @param v
     * @return True if vertex v is present in the graph, false otherwise.
     */
    public boolean hasVertex(T v) {
        /* TODO */
    }

    /**
     * Provides access to every vertex in the graph.
     *
     * @return An object that iterates over V.
     */
    public Iterable<T> getVertices() {
        /* TODO */
    }

    /**
     * @return |E|
     */
    public int getEdgeCount() {
        /* TODO */
    }

    /**
     * @param u One endpoint of the edge.
     * @param v The other endpoint of the edge.
     * @return True if edge (u,v) is present in the graph, false otherwise.
     */
    public boolean hasEdge(T u, T v) {
        /* TODO */
    }

    /**
     * Returns all neighbors of vertex u.
     *
     * @param u A vertex.
     * @return The neighbors of u.
     */
    public Iterable<T> getNeighbors(T u) {
        /* TODO */
    }


    /**
     * @param u
     * @param v
     * @return True if v is a neighbor of u.
     */
    public boolean isNeighbor(T u, T v) {
        /* TODO */
    }

    /**
     * Finds the length of the shortest path from vertex s to all other vertices in the graph.
     *
     * @param s The source vertex.
     * @return A map of shortest path distances. Every reachable vertex v should be present as a key mapped to the length of the shortest s->v path. 
     */
    public Map<T, Long> getShortestPaths(T s) {
        /* TODO */
    }
}
