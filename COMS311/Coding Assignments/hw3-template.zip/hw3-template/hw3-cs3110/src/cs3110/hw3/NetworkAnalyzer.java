package cs3110.hw3;

import java.util.List;
import java.util.Map;

public class NetworkAnalyzer {
    public NetworkAnalyzer(List<String> hosts, Map<String,String> simplexConnections, Map<String,String> duplexConnections) {
        /* TODO */
    }

    public long findMaxDeliveryTime() {
        /* TODO */
    }

    public int countMinToReconnect(Map<String,String> simplexConnectionsToRemove) {
        /* TODO */
    }
}
